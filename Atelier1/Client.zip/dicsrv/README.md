# DicSrv
Basic non secured server to share a dictionary between users.
